export const sidebarData = [
  {
    title: "Dashboard",
    // icon: "home", Use this if you want to add icons
    link: "/app/dashboard",
  },
  {
    title: "Users",
    // icon: "home", Use this if you want to add icons
    link: "/app/users",
  },
  {
    title: "Cleaners",
    // icon: "home", Use this if you want to add icons
    link: "/app/cleaners",
  },
];
