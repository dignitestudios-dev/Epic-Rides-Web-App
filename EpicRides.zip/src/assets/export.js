// In this file you'll import all the image and files that you want to export to the rest of the application.
// You can import the files and export them with a different name if you want.
// Example:

// import FILENAME(PASCALCASE) from "./FILENAME(CAMELCASE).png";
import NoInternetImage from "./nointernet.png";
import loginbackgroundimage from "./login/backgroundimage.webp";
import logo from "./logo.png";
import barone from "./signup/barone.png"
import bartwo from "./signup/bartwo.png"
import barthree from "./signup/barthree.png"
import sedan from "./cars/sedan.png"
import SUV from "./cars/SUV.png"
import Hash from "./cars/Hash.png"





export { logo, NoInternetImage,loginbackgroundimage,barone,bartwo,barthree,sedan,SUV,Hash };
